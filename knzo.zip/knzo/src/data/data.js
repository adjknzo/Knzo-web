export const technologies = [
  "WordPress", "React", "Shopify", "Google Ads", "Meta", "Tailwind CSS", "Next.js", "GA4", "HubSpot", "Figma", "Make.com", "Zapier"
];

export const servicesData = [
  { id: 1, title: "Web Development", icon: "🌐", desc: "Custom websites, e-commerce, speed optimization & API integration." },
  { id: 2, title: "UI/UX Design", icon: "🎨", desc: "Wireframing, prototyping, user journey mapping & SaaS design." },
  { id: 3, title: "Graphic Design", icon: "🖌️", desc: "Logo design, brand identity, social media graphics & print." },
  { id: 4, title: "SEO Services", icon: "📈", desc: "Technical SEO, keyword research, link building & E-E-A-T." },
  { id: 5, title: "Local SEO & GMB", icon: "📍", desc: "Google Business Profile, local citations, NAP & maps ranking." },
  { id: 6, title: "Social Media Marketing", icon: "📱", desc: "Content calendars, community management & organic growth." },
  { id: 7, title: "Paid Advertising & PPC", icon: "📢", desc: "Google Ads, Meta Ads, LinkedIn Ads, retargeting & ROAS." },
  { id: 8, title: "Content & Copywriting", icon: "✍️", desc: "SEO blog posts, landing page copy, ad copy & brand messaging." },
  { id: 9, title: "Video Editing", icon: "🎬", desc: "Reels, TikTok, YouTube videos, motion graphics & color grading." },
  { id: 10, title: "Photography", icon: "📸", desc: "Product photography, corporate shoots & photo retouching." },
  { id: 11, title: "AI & Automation", icon: "🤖", desc: "AI chatbots, Make.com workflows, CRM automation & lead capture." },
  { id: 12, title: "Email Marketing", icon: "📧", desc: "Newsletter design, welcome sequences & cart recovery." },
  { id: 13, title: "Lead Generation", icon: "🎯", desc: "B2B & B2C lead gen, LinkedIn outreach & landing page funnels." },
  { id: 14, title: "Branding & Strategy", icon: "💼", desc: "Brand positioning, go-to-market strategy & consulting." },
  { id: 15, title: "E-commerce Services", icon: "🛒", desc: "Shopify setup, product optimization, cart recovery & store performance." },
  { id: 16, title: "Conversion Optimization", icon: "⚡", desc: "A/B testing, heatmap analysis, funnel & mobile conversion." },
  { id: 17, title: "Analytics & Reporting", icon: "📊", desc: "GA4 setup, Looker Studio dashboards & event tracking." },
  { id: 18, title: "CMS Platforms", icon: "🧑‍💻", desc: "WordPress, Shopify, Webflow, and headless CMS integration." },
  { id: 19, title: "Technical Services", icon: "🛠️", desc: "DNS setup, SSL, backups, security hardening & migrations." },
  { id: 20, title: "Reputation Management", icon: "🔗", desc: "Google review management, brand monitoring & trust signals." },
  { id: 21, title: "Pinterest Marketing", icon: "📌", desc: "Pinterest SEO, board optimization & website traffic." },
  { id: 22, title: "Software Engineering", icon: "💻", desc: "HTML, CSS, JavaScript, Git, API integration & code optimization." },
  { id: 23, title: "Social Media Management", icon: "📲", desc: "Facebook, Instagram, LinkedIn, TikTok & YouTube management." },
  { id: 24, title: "Virtual Business Support", icon: "📝", desc: "Data entry, market research, CRM management & file organization." },
];

export const portfolioData = [
  { id: 1, title: "Montfort Real Estate", category: "Web Development", link: "https://montfortre.com/", img: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?q=80&w=1973&auto=format&fit=crop" },
  { id: 2, title: "Armas Group NYC", category: "Web Development", link: "https://www.armasgroupnyc.com/", img: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=2070&auto=format&fit=crop" },
  { id: 3, title: "NYC Luxury Club", category: "SEO Services", link: "https://nycluxuryclub.com/", img: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?q=80&w=1974&auto=format&fit=crop" },
];