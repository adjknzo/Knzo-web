import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Yahan FAQs add kar diya gaya hai
  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Services', path: '/services' },
    { name: 'Portfolio', path: '/portfolio' },
    { name: 'Pricing', path: '/pricing' },
    { name: 'FAQs', path: '/faqs' },
  ];

  return (
    <header className={`fixed w-full top-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white/90 backdrop-blur-lg border-b border-gray-100 shadow-sm py-3' : 'bg-transparent py-5'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-9 h-9 bg-brand-blue rounded-xl flex items-center justify-center text-white font-bold text-xl group-hover:rotate-12 transition-transform duration-300">K</div>
          <span className="font-heading font-bold text-2xl text-brand-dark tracking-tight">KNZO <span className="text-brand-grey font-normal text-xl">Studio</span></span>
        </Link>

        <nav className="hidden lg:flex items-center gap-6 font-medium text-sm text-brand-dark">
          {navLinks.map((link) => (
            <Link key={link.name} to={link.path} className="hover:text-brand-blue transition">{link.name}</Link>
          ))}
        </nav>

        <div className="hidden lg:flex items-center gap-4">
          <Link to="/contact" className="bg-brand-dark text-white px-6 py-2.5 rounded-xl font-medium text-sm hover:bg-brand-blue hover:shadow-lg hover:shadow-brand-blue/30 transition-all duration-300">Get a Quote</Link>
        </div>

        <button className="lg:hidden text-brand-dark" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          {isMobileMenuOpen ? <X className="w-7 h-7" /> : <Menu className="w-7 h-7" />}
        </button>
      </div>

      {isMobileMenuOpen && (
        <div className="lg:hidden absolute top-full left-0 w-full bg-white border-b border-gray-100 shadow-lg py-4 px-6 flex flex-col gap-4">
          {navLinks.map((link) => (
            <Link key={link.name} to={link.path} onClick={() => setIsMobileMenuOpen(false)} className="text-brand-dark font-medium hover:text-brand-blue">{link.name}</Link>
          ))}
          <Link to="/contact" onClick={() => setIsMobileMenuOpen(false)} className="bg-brand-blue text-white px-6 py-3 rounded-xl text-center font-medium mt-2">Get a Quote</Link>
        </div>
      )}
    </header>
  );
}