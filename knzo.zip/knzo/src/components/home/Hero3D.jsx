import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Sphere, MeshDistortMaterial } from '@react-three/drei';
import { useRef } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

function AnimatedSphere() {
  const meshRef = useRef();
  
  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    meshRef.current.rotation.x = t * 0.2;
    meshRef.current.rotation.y = t * 0.3;
  });

  return (
    <Sphere visible args={[1, 100, 200]} scale={2.2} ref={meshRef}>
      <MeshDistortMaterial
        color="#2563EB"
        attach="material"
        distort={0.4}
        speed={2}
        roughness={0.2}
        metalness={0.8}
      />
    </Sphere>
  );
}

export default function Hero3D() {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-brand-light">
      <div className="max-w-7xl mx-auto px-6 relative z-10 grid lg:grid-cols-2 gap-12 items-center w-full">
        
        {/* Left Text Content */}
        <div className="space-y-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-50 text-brand-blue font-medium text-sm border border-blue-100">
            <span className="w-2 h-2 rounded-full bg-brand-blue animate-pulse"></span>
            Full-Service Digital Agency
          </div>
          
          <h1 className="font-heading text-5xl lg:text-7xl font-extrabold text-brand-dark leading-[1.1]">
            We Build. Market. <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-blue to-blue-400">
              Grow.
            </span>
          </h1>
          
          <p className="text-lg text-brand-grey max-w-lg leading-relaxed">
            KNZO Studio helps businesses in Pakistan and globally scale with high-converting websites, SEO, and AI automation.
          </p>
          
          <div className="flex flex-wrap items-center gap-5">
            <Link to="/contact" className="bg-brand-blue text-white px-8 py-4 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-xl shadow-brand-blue/30 flex items-center gap-2 group">
              Get Started
              <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link to="/services" className="flex items-center gap-2 text-brand-dark font-bold hover:text-brand-blue transition px-4 py-4">
              Explore Services
            </Link>
          </div>
        </div>

        {/* Right 3D Canvas */}
        <div className="relative h-[400px] lg:h-[600px] w-full cursor-grab active:cursor-grabbing">
          <Canvas camera={{ position: [0, 0, 5] }}>
            <ambientLight intensity={1} />
            <directionalLight position={[2, 5, 2]} intensity={2} />
            <AnimatedSphere />
            <OrbitControls enableZoom={false} autoRotate autoRotateSpeed={1.5} />
          </Canvas>
          
          {/* Floating Cards Over 3D */}
          <div className="absolute top-10 -left-4 lg:left-0 bg-white/90 backdrop-blur-md p-4 rounded-2xl shadow-xl border border-white animate-float">
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">SEO & GMB</p>
            <p className="font-heading font-bold text-brand-dark">Rank Globally</p>
          </div>
          
          <div className="absolute bottom-10 -right-4 lg:right-0 bg-white/90 backdrop-blur-md p-4 rounded-2xl shadow-xl border border-white animate-float-delay">
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">AI & Automation</p>
            <p className="font-heading font-bold text-brand-dark">Smart Workflows</p>
          </div>
        </div>
      </div>
    </section>
  );
}