import { technologies } from '../../data/data'; // Hum abhi data file banayenge

export default function TechMarquee() {
  return (
    <section className="py-10 bg-white border-y border-gray-100 overflow-hidden">
      <p className="text-center text-xs font-bold text-gray-400 uppercase tracking-[0.2em] mb-6">Technologies We Master</p>
      <div className="flex w-[200%] animate-marquee opacity-60">
        {[...technologies, ...technologies].map((tech, index) => (
          <div key={index} className="mx-8 text-2xl font-bold font-heading text-brand-dark whitespace-nowrap">
            {tech}
          </div>
        ))}
      </div>
    </section>
  );
}