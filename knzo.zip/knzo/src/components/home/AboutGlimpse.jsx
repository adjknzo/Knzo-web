import { CheckCircle2, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function AboutGlimpse() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center">
        
        {/* Left Images */}
        <div className="relative">
          <img 
            src="https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=2070&auto=format&fit=crop" 
            alt="Team Working" 
            className="rounded-3xl w-4/5 h-80 object-cover shadow-lg"
          />
          <img 
            src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=2071&auto=format&fit=crop" 
            alt="Office Meeting" 
            className="absolute bottom-0 right-0 rounded-3xl w-3/5 h-64 object-cover border-8 border-white shadow-xl"
          />
        </div>

        {/* Right Content */}
        <div>
          <h2 className="font-heading text-4xl font-bold text-brand-dark mb-6">Why Choose KNZO Studio?</h2>
          <p className="text-brand-grey mb-8 leading-relaxed">
            Based in Lahore, Pakistan, we are a team of passionate developers, designers, and digital marketers. We don't just build websites; we build growth engines for businesses in Pakistan and globally.
          </p>
          
          <ul className="space-y-4 mb-8">
            <li className="flex items-start gap-3">
              <CheckCircle2 className="text-brand-blue shrink-0 mt-1" />
              <div>
                <h4 className="font-bold text-brand-dark">Full-Stack Expertise</h4>
                <p className="text-sm text-brand-grey">From custom coding to running global ad campaigns.</p>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="text-brand-blue shrink-0 mt-1" />
              <div>
                <h4 className="font-bold text-brand-dark">Global Reach</h4>
                <p className="text-sm text-brand-grey">Successfully serving clients in Pakistan, USA, and Mexico.</p>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <CheckCircle2 className="text-brand-blue shrink-0 mt-1" />
              <div>
                <h4 className="font-bold text-brand-dark">Result-Driven Approach</h4>
                <p className="text-sm text-brand-grey">We focus on conversions, rankings, and actual business growth.</p>
              </div>
            </li>
          </ul>

          <Link to="/about" className="inline-flex items-center gap-2 bg-brand-dark text-white px-6 py-3 rounded-xl font-medium hover:bg-brand-blue transition">
            Learn More About Us <ArrowRight size={18} />
          </Link>
        </div>

      </div>
    </section>
  );
}