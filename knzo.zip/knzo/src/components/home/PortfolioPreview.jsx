import { portfolioData } from '../../data/data';
import { ArrowUpRight } from 'lucide-react';

export default function PortfolioPreview() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12">
          <div>
            <h2 className="font-heading text-4xl font-bold text-brand-dark mb-2">Recent Work</h2>
            <p className="text-brand-grey">Real results for real businesses across the globe.</p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {portfolioData.map((project) => (
            <a key={project.id} href={project.link} target="_blank" rel="noreferrer" className="group rounded-3xl overflow-hidden relative aspect-[4/3] bg-gray-200 border border-gray-100 block">
              <img src={project.img} alt={project.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                <span className="text-xs font-bold text-brand-blue bg-white/90 w-fit px-2 py-1 rounded mb-2">{project.category}</span>
                <div className="flex justify-between items-center">
                  <h3 className="text-white font-heading font-bold text-xl">{project.title}</h3>
                  <ArrowUpRight className="text-white" />
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}