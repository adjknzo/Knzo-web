import { useState } from 'react';
import { MessageCircle } from 'lucide-react';

export default function QuoteForm() {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', service: 'Web Development', details: '' });

  const handleSubmit = (e) => {
    e.preventDefault();
    const message = `*New Quote Request - KNZO Studio*%0A%0A*Name:* ${formData.name}%0A*Email:* ${formData.email}%0A*Phone:* ${formData.phone}%0A*Service:* ${formData.service}%0A%0A*Details:*%0A${formData.details}`;
    window.open(`https://wa.me/923036887134?text=${message}`, '_blank');
  };

  return (
    <section className="py-24 bg-brand-dark text-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center relative z-10">
        <div>
          <h2 className="font-heading text-4xl lg:text-5xl font-bold mb-6 leading-tight">Ready to scale your business?</h2>
          <p className="text-gray-400 text-lg mb-8 max-w-md">Get a custom quote for your project. Fill out the form and we will get back to you immediately via WhatsApp.</p>
          <div className="space-y-4 text-gray-300">
            <p>📞 +92 303 6887134</p>
            <p>✉️ knzostudio@gmail.com</p>
            <p>📍 Lahore, Pakistan</p>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-8 shadow-2xl">
          <h3 className="font-heading text-2xl font-bold text-brand-dark mb-6">Get a Custom Quote</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <input type="text" placeholder="Full Name" required className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 text-brand-dark focus:outline-none focus:border-brand-blue" onChange={(e) => setFormData({...formData, name: e.target.value})} />
              <input type="email" placeholder="Email Address" required className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 text-brand-dark focus:outline-none focus:border-brand-blue" onChange={(e) => setFormData({...formData, email: e.target.value})} />
            </div>
            <input type="text" placeholder="Phone Number" required className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 text-brand-dark focus:outline-none focus:border-brand-blue" onChange={(e) => setFormData({...formData, phone: e.target.value})} />
            <select className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 text-brand-dark focus:outline-none focus:border-brand-blue" onChange={(e) => setFormData({...formData, service: e.target.value})}>
              <option>Web Development</option>
              <option>SEO Services</option>
              <option>GMB Ranking</option>
              <option>Other</option>
            </select>
            <textarea rows="3" placeholder="Project Details..." required className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 text-brand-dark focus:outline-none focus:border-brand-blue" onChange={(e) => setFormData({...formData, details: e.target.value})}></textarea>
            <button type="submit" className="w-full bg-[#25D366] text-white font-bold py-4 rounded-xl hover:bg-green-600 transition flex items-center justify-center gap-2">
              <MessageCircle size={20} /> Send via WhatsApp
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}