import { Settings, PenTool, Code, Rocket, HeartPulse, ShoppingBag, Utensils, Building2, GraduationCap, Briefcase } from 'lucide-react';

export default function ProcessAndIndustries() {
  const steps = [
    { icon: <Settings size={24} />, title: "Discovery", desc: "We understand your goals and audience." },
    { icon: <PenTool size={24} />, title: "Strategy & Design", desc: "We create wireframes and visual designs." },
    { icon: <Code size={24} />, title: "Development", desc: "We code your website with latest tech." },
    { icon: <Rocket size={24} />, title: "Launch & Scale", desc: "We test, launch, and optimize for growth." },
  ];

  const industries = [
    { icon: <Building2 size={32} />, name: "Real Estate" },
    { icon: <HeartPulse size={32} />, name: "Healthcare" },
    { icon: <ShoppingBag size={32} />, name: "E-commerce" },
    { icon: <Utensils size={32} />, name: "Restaurants" },
    { icon: <GraduationCap size={32} />, name: "Education" },
    { icon: <Briefcase size={32} />, name: "Professional Services" },
  ];

  return (
    <section className="py-24 bg-brand-light border-y border-gray-100">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Process Section */}
        <div className="mb-24">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="font-heading text-4xl font-bold text-brand-dark mb-4">How We Work</h2>
            <p className="text-brand-grey">A proven process to take your business from idea to execution.</p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-8 relative">
            {/* Connecting Line (Desktop) */}
            <div className="hidden md:block absolute top-8 left-[10%] right-[10%] h-0.5 bg-blue-100 -z-10"></div>
            
            {steps.map((step, idx) => (
              <div key={idx} className="text-center relative">
                <div className="w-16 h-16 mx-auto bg-white border-4 border-brand-light shadow-md rounded-full flex items-center justify-center text-brand-blue mb-6 relative z-10">
                  {step.icon}
                </div>
                <h3 className="font-heading font-bold text-lg text-brand-dark mb-2">{step.title}</h3>
                <p className="text-sm text-brand-grey">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Industries Section */}
        <div>
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="font-heading text-3xl font-bold text-brand-dark mb-4">Industries We Serve</h2>
            <p className="text-brand-grey">We bring our expertise to a wide range of industries.</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {industries.map((ind, idx) => (
              <div key={idx} className="bg-white p-6 rounded-2xl border border-gray-100 text-center hover:shadow-lg transition">
                <div className="text-brand-blue mx-auto mb-3 flex justify-center">{ind.icon}</div>
                <h4 className="font-bold text-brand-dark text-sm">{ind.name}</h4>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}