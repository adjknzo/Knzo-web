import { servicesData } from '../../data/data';

export default function ServicesGrid() {
  return (
    <section className="py-24 bg-brand-light">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="font-heading text-4xl font-bold text-brand-dark mb-4">Our Agency Services</h2>
          <p className="text-brand-grey text-lg">We are a full-stack digital agency. From code to creativity, marketing to AI, we handle everything your business needs to scale.</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {servicesData.map((service) => (
            <div key={service.id} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-xl hover:-translate-y-2 transition-all duration-300">
              <div className="text-3xl mb-4">{service.icon}</div>
              <h3 className="font-heading font-bold text-lg text-brand-dark mb-2">{service.title}</h3>
              <p className="text-xs text-brand-grey leading-relaxed">{service.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}