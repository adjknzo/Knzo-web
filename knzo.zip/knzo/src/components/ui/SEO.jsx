import { Helmet } from 'react-helmet-async';

export default function SEO({ title, description, keywords }) {
  const defaultTitle = "KNZO Studio | Digital Marketing & Web Development Agency";
  const defaultDesc = "Premium Full-Service Digital Agency based in Lahore, Pakistan. We build, market, and scale businesses globally.";
  
  return (
    <Helmet>
      <title>{title ? `${title} | KNZO Studio` : defaultTitle}</title>
      <meta name="description" content={description || defaultDesc} />
      {keywords && <meta name="keywords" content={keywords} />}
      
      {/* Open Graph Tags for Social Media */}
      <meta property="og:title" content={title ? `${title} | KNZO Studio` : defaultTitle} />
      <meta property="og:description" content={description || defaultDesc} />
      <meta property="og:type" content="website" />
    </Helmet>
  );
}