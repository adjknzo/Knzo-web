import SEO from '../components/ui/SEO';
import { servicesData } from '../data/data';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Services() {
  return (
    <div className="pt-32 pb-20 bg-brand-light min-h-screen">
      <SEO 
        title="Our Services" 
        description="Explore our full range of digital services including Web Development, UI/UX, SEO, Social Media Marketing, and AI Automation."
        keywords="web development, seo services, social media marketing, ai automation"
      />
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h1 className="font-heading text-5xl font-bold text-brand-dark mb-6">Our Services</h1>
          <p className="text-lg text-brand-grey">We are a full-stack digital agency. From code to creativity, marketing to AI, we handle everything your business needs to scale.</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {servicesData.map((service) => (
            <div key={service.id} className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 hover:shadow-xl transition-all duration-300 group">
              <div className="text-4xl mb-4 group-hover:scale-110 transition-transform origin-left">{service.icon}</div>
              <h3 className="font-heading font-bold text-xl text-brand-dark mb-3">{service.title}</h3>
              <p className="text-sm text-brand-grey leading-relaxed mb-6">{service.desc}</p>
              <Link to="/contact" className="text-brand-blue font-semibold text-sm hover:text-blue-700 flex items-center gap-2">Get Quote <ArrowRight size={16} /></Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}