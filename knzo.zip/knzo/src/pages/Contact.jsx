import SEO from '../components/ui/SEO';
import { MessageCircle, Mail, Phone, MapPin } from 'lucide-react';
import { useState } from 'react';

export default function Contact() {
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', service: 'Web Development', details: '' });

  const handleSubmit = (e) => {
    e.preventDefault();
    const message = `*New Inquiry - KNZO Studio*%0A%0A*Name:* ${formData.name}%0A*Email:* ${formData.email}%0A*Phone:* ${formData.phone}%0A*Service:* ${formData.service}%0A%0A*Details:*%0A${formData.details}`;
    window.open(`https://wa.me/923036887134?text=${message}`, '_blank');
  };

  return (
    <div className="pt-32 pb-20 bg-white min-h-screen">
      <SEO 
        title="Contact Us" 
        description="Get in touch with KNZO Studio for web development, SEO, or digital marketing services. Send us a message on WhatsApp."
      />
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h1 className="font-heading text-5xl font-bold text-brand-dark mb-6">Contact Us</h1>
          <p className="text-lg text-brand-grey">Have a project in mind? Let's discuss how we can help you grow.</p>
        </div>
        <div className="grid lg:grid-cols-2 gap-16">
          <div className="space-y-8">
            <h2 className="font-heading text-3xl font-bold text-brand-dark">Get in Touch</h2>
            <p className="text-brand-grey">We are available for inquiries and consultations. Reach out to us via WhatsApp, Email, or Phone.</p>
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-50 text-brand-blue rounded-xl flex items-center justify-center"><Phone /></div>
                <div><p className="text-sm text-gray-500 font-medium">Call Us</p><a href="tel:+923036887134" className="font-bold text-brand-dark hover:text-brand-blue">+92 303 6887134</a></div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-50 text-brand-blue rounded-xl flex items-center justify-center"><Mail /></div>
                <div><p className="text-sm text-gray-500 font-medium">Email Us</p><a href="mailto:knzostudio@gmail.com" className="font-bold text-brand-dark hover:text-brand-blue">knzostudio@gmail.com</a></div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-blue-50 text-brand-blue rounded-xl flex items-center justify-center"><MapPin /></div>
                <div><p className="text-sm text-gray-500 font-medium">Location</p><p className="font-bold text-brand-dark">Lahore, Pakistan</p></div>
              </div>
            </div>
          </div>
          <div className="bg-brand-light p-8 rounded-3xl border border-gray-100 shadow-sm">
            <h3 className="font-heading text-2xl font-bold text-brand-dark mb-6">Send a Message</h3>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-2 gap-4">
                <input type="text" placeholder="Full Name" required className="w-full px-4 py-3 rounded-xl bg-white border border-gray-200 focus:outline-none focus:border-brand-blue" onChange={(e) => setFormData({...formData, name: e.target.value})} />
                <input type="email" placeholder="Email" required className="w-full px-4 py-3 rounded-xl bg-white border border-gray-200 focus:outline-none focus:border-brand-blue" onChange={(e) => setFormData({...formData, email: e.target.value})} />
              </div>
              <input type="text" placeholder="Phone Number" required className="w-full px-4 py-3 rounded-xl bg-white border border-gray-200 focus:outline-none focus:border-brand-blue" onChange={(e) => setFormData({...formData, phone: e.target.value})} />
              <select className="w-full px-4 py-3 rounded-xl bg-white border border-gray-200 focus:outline-none focus:border-brand-blue" onChange={(e) => setFormData({...formData, service: e.target.value})}>
                <option>Web Development</option>
                <option>SEO Services</option>
                <option>GMB Ranking</option>
                <option>Other</option>
              </select>
              <textarea rows="4" placeholder="Project Details..." required className="w-full px-4 py-3 rounded-xl bg-white border border-gray-200 focus:outline-none focus:border-brand-blue" onChange={(e) => setFormData({...formData, details: e.target.value})}></textarea>
              <button type="submit" className="w-full bg-[#25D366] text-white font-bold py-4 rounded-xl hover:bg-green-600 transition flex items-center justify-center gap-2"><MessageCircle size={20} /> Send via WhatsApp</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}