import { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

export default function FAQs() {
  const [openIndex, setOpenIndex] = useState(null);

  const faqs = [
    { q: "What services does KNZO Studio offer?", a: "We offer a full range of digital services including Web Development, UI/UX Design, SEO, Local GMB Ranking, Social Media Marketing, Paid Ads, AI Automation, Video Editing, and more." },
    { q: "How can I get started?", a: "Simply go to our Contact page and fill out the form. It will redirect you to WhatsApp where we can discuss your project immediately." },
    { q: "Do you work with international clients?", a: "Yes, we are based in Lahore, Pakistan, but we serve clients globally, including the USA, UK, and Mexico." },
    { q: "Do you offer custom website development?", a: "Absolutely. We build custom websites from scratch based on your specific business needs, using modern frameworks like React and WordPress." },
    { q: "How much does a website cost?", a: "Every project is unique. We provide custom quotes based on your requirements, features, and timeline. Contact us for a free estimate." },
    { q: "How long does a project take?", a: "A standard business website takes 2-4 weeks. Complex web applications or extensive SEO campaigns may take longer. We provide a timeline upfront." },
    { q: "Do you provide website maintenance?", a: "Yes, we offer ongoing website maintenance packages including updates, security checks, and backups." },
    { q: "Do you offer monthly SEO packages?", a: "Yes, we offer monthly SEO retainers for local and international businesses looking to rank higher on Google." },
    { q: "Can I request a custom service package?", a: "Yes. We can mix and match services (e.g., Web Design + SEO + Ads) to create a package that fits your exact goals." },
    { q: "Do you provide revisions?", a: "Yes, we provide revisions during the design and development phase to ensure you are 100% satisfied." },
    { q: "What payment methods do you accept?", a: "We accept Bank Transfers, Wise, Payoneer, and other international payment methods." },
    { q: "Do you sign service agreements?", a: "Yes, we provide a clear contract outlining the scope of work, timeline, and deliverables before starting." },
    { q: "Will I own my website after completion?", a: "Yes, once the final payment is made, you have full ownership of the website, domain, and hosting." },
    { q: "Do you provide ongoing technical support?", a: "Yes, we offer technical support and maintenance plans after project completion." },
    { q: "Can I hire you for a single service?", a: "Yes, you can hire us for just a logo, just SEO, or just a website. Whatever you need." }
  ];

  return (
    <div className="pt-32 pb-20 bg-brand-light min-h-screen">
      <div className="max-w-3xl mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="font-heading text-5xl font-bold text-brand-dark mb-6">Frequently Asked Questions</h1>
          <p className="text-lg text-brand-grey">Everything you need to know before starting a project with us.</p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div key={index} className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm">
              <button 
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex justify-between items-center p-6 text-left font-bold text-brand-dark hover:text-brand-blue transition"
              >
                {faq.q}
                {openIndex === index ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
              </button>
              {openIndex === index && (
                <div className="px-6 pb-6 text-brand-grey text-sm leading-relaxed">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}