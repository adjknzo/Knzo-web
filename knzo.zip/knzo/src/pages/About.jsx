import SEO from '../components/ui/SEO';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function About() {
  return (
    <div className="pt-32 pb-20 bg-brand-light min-h-screen">
      <SEO 
        title="About Us" 
        description="Learn about KNZO Studio, a full-service digital agency based in Lahore, Pakistan, serving clients globally."
      />
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h1 className="font-heading text-5xl font-bold text-brand-dark mb-6">About KNZO Studio</h1>
          <p className="text-lg text-brand-grey">We are a full-service digital agency based in Lahore, Pakistan. We bridge the gap between creativity and technology.</p>
        </div>
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-6">
            <h2 className="font-heading text-3xl font-bold text-brand-dark">Our Story</h2>
            <p className="text-brand-grey leading-relaxed">Whether you are a local business in Pakistan looking to dominate Google Maps, or an international brand needing a high-end web application, our team of developers, designers, and marketers is equipped to deliver.</p>
            <div className="space-y-4 mt-8">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="text-brand-blue shrink-0 mt-1" />
                <div>
                  <h4 className="font-bold text-brand-dark">Full-Stack Expertise</h4>
                  <p className="text-sm text-brand-grey">From coding websites to running global ad campaigns.</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle2 className="text-brand-blue shrink-0 mt-1" />
                <div>
                  <h4 className="font-bold text-brand-dark">Global Reach</h4>
                  <p className="text-sm text-brand-grey">Successfully serving clients in Pakistan, USA (NYC), and Mexico.</p>
                </div>
              </div>
            </div>
          </div>
          <div className="relative">
            <div className="rounded-3xl overflow-hidden shadow-2xl aspect-[4/3] border-8 border-white bg-gray-200">
               <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=2070&auto=format&fit=crop" alt="KNZO Studio Team" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>
        <div className="mt-24 bg-brand-dark rounded-3xl p-10 md:p-16 text-center text-white">
          <h2 className="font-heading text-3xl font-bold mb-4">Website Sample for Serious Clients</h2>
          <p className="text-gray-300 max-w-2xl mx-auto mb-8">If you're seriously interested in working with us, we can create a sample website design for your business.</p>
          <Link to="/contact" className="inline-flex items-center gap-2 bg-brand-blue text-white px-8 py-4 rounded-xl font-bold hover:bg-blue-700 transition">
            Request a Sample <ArrowRight size={20} />
          </Link>
        </div>
      </div>
    </div>
  );
}