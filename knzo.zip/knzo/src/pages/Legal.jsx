import { useLocation } from 'react-router-dom';

export default function Legal() {
  const location = useLocation();
  const isPrivacy = location.pathname === '/privacy-policy';
  const isTerms = location.pathname === '/terms';
  
  const title = isPrivacy ? "Privacy Policy" : isTerms ? "Terms & Conditions" : "Refund Policy";

  return (
    <div className="pt-32 pb-20 bg-white min-h-screen">
      <div className="max-w-4xl mx-auto px-6">
        <h1 className="font-heading text-4xl font-bold text-brand-dark mb-8">{title}</h1>
        <div className="prose prose-slate max-w-none text-brand-grey">
          <p>Last updated: {new Date().toLocaleDateString()}</p>
          <p className="mt-4">This is a standard {title} for KNZO Studio. By using our website and services, you agree to these terms.</p>
          
          <h3 className="text-xl font-bold text-brand-dark mt-8 mb-4">1. Information We Collect</h3>
          <p>We only collect information you provide via our contact forms, such as your name, email, phone number, and project details. We use this to communicate with you about your project.</p>
          
          <h3 className="text-xl font-bold text-brand-dark mt-8 mb-4">2. How We Use Your Data</h3>
          <p>We do not sell or share your data with third parties. Your information is used solely to provide our services and improve your experience with our agency.</p>
          
          <h3 className="text-xl font-bold text-brand-dark mt-8 mb-4">3. Payment & Refunds</h3>
          <p>Payments are handled securely. Refunds are subject to the scope of work defined in your individual service agreement. Please contact us for detailed terms.</p>
          
          <p className="mt-8">If you have any questions regarding these policies, please contact us at knzostudio@gmail.com.</p>
        </div>
      </div>
    </div>
  );
}