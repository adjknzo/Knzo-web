import SEO from '../components/ui/SEO';
import Hero3D from '../components/home/Hero3D';
import TechMarquee from '../components/home/TechMarquee';
import AboutGlimpse from '../components/home/AboutGlimpse';
import ServicesGrid from '../components/home/ServicesGrid';
import ProcessAndIndustries from '../components/home/ProcessAndIndustries';
import PortfolioPreview from '../components/home/PortfolioPreview';
import QuoteForm from '../components/home/QuoteForm';

export default function Home() {
  return (
    <div>
      <SEO 
        title="Digital Marketing & Web Development Agency" 
        description="KNZO Studio offers Web Development, SEO, GMB Ranking, and AI Automation. Based in Lahore, serving clients globally."
        keywords="digital agency lahore, web development pakistan, seo services, gmb ranking"
      />
      <Hero3D />
      <TechMarquee />
      <AboutGlimpse />
      <ServicesGrid />
      <ProcessAndIndustries />
      <PortfolioPreview />
      <QuoteForm />
    </div>
  );
}