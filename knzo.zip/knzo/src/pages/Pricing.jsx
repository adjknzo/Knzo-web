import SEO from '../components/ui/SEO';
import { Link } from 'react-router-dom';
import { Check } from 'lucide-react';

export default function Pricing() {
  const packages = [
    { name: "Starter", desc: "Ideal for small businesses getting started.", features: ["Basic Website Design", "Local SEO Setup", "GMB Profile Optimization", "1 Month Support"] },
    { name: "Growth", desc: "For brands ready to scale their presence.", features: ["Custom Web Development", "Advanced SEO & Content", "Social Media Management", "Google/Meta Ads Setup", "3 Months Support"], popular: true },
    { name: "Enterprise", desc: "Full-scale operations and global reach.", features: ["Custom Web Applications", "Global SEO Strategy", "AI Automation Workflows", "Dedicated Account Manager", "Ongoing Maintenance"] }
  ];

  return (
    <div className="pt-32 pb-20 bg-brand-light min-h-screen">
      <SEO 
        title="Pricing & Packages" 
        description="Request a custom quote for your digital project. We offer tailored solutions for web development, SEO, and marketing."
      />
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h1 className="font-heading text-5xl font-bold text-brand-dark mb-6">Tailored Solutions</h1>
          <p className="text-lg text-brand-grey">Every business is unique. We don't do one-size-fits-all pricing. We build a custom quote based on your needs.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {packages.map((pkg, idx) => (
            <div key={idx} className={`bg-white rounded-3xl p-8 border ${pkg.popular ? 'border-brand-blue shadow-2xl relative' : 'border-gray-100 shadow-sm'}`}>
              {pkg.popular && <span className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-brand-blue text-white px-4 py-1 rounded-full text-xs font-bold uppercase tracking-wider">Most Popular</span>}
              <h3 className="font-heading text-2xl font-bold text-brand-dark mb-2">{pkg.name}</h3>
              <p className="text-sm text-brand-grey mb-6 h-10">{pkg.desc}</p>
              <ul className="space-y-4 mb-8">
                {pkg.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-3 text-sm text-brand-dark"><Check size={18} className="text-brand-blue shrink-0" /> {feature}</li>
                ))}
              </ul>
              <Link to="/contact" className={`w-full block text-center py-3 rounded-xl font-bold transition ${pkg.popular ? 'bg-brand-blue text-white hover:bg-blue-700' : 'bg-gray-100 text-brand-dark hover:bg-gray-200'}`}>Get a Custom Quote</Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}