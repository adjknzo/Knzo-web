import { useState } from 'react';
import SEO from '../components/ui/SEO';
import { portfolioData } from '../data/data';
import { ArrowUpRight } from 'lucide-react';

export default function Portfolio() {
  const [filter, setFilter] = useState('All');
  const filteredProjects = filter === 'All' ? portfolioData : portfolioData.filter(p => p.category === filter);

  return (
    <div className="pt-32 pb-20 bg-white min-h-screen">
      <SEO 
        title="Our Work & Portfolio" 
        description="View our previous projects including Web Development, SEO Rankings, and Local GMB Optimization for clients in Pakistan, USA, and Mexico."
      />
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h1 className="font-heading text-5xl font-bold text-brand-dark mb-6">Our Previous Work</h1>
          <p className="text-lg text-brand-grey">Real results for real businesses across the globe.</p>
        </div>
        <div className="flex justify-center gap-4 mb-12 flex-wrap">
          {['All', 'Web Development', 'SEO Services', 'GMB Ranking'].map((cat) => (
            <button key={cat} onClick={() => setFilter(cat)} className={`px-6 py-2.5 rounded-full font-medium text-sm transition-all ${filter === cat ? 'bg-brand-dark text-white shadow-lg' : 'bg-gray-100 text-brand-dark hover:bg-gray-200'}`}>{cat}</button>
          ))}
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <a key={project.id} href={project.link} target="_blank" rel="noreferrer" className="group rounded-3xl overflow-hidden relative aspect-[4/3] bg-gray-200 border border-gray-100 block">
              <img src={project.img} alt={project.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                <span className="text-xs font-bold text-brand-blue bg-white/90 w-fit px-2 py-1 rounded mb-2">{project.category}</span>
                <div className="flex justify-between items-center">
                  <h3 className="text-white font-heading font-bold text-xl">{project.title}</h3>
                  <ArrowUpRight className="text-white" />
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}