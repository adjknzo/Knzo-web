import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-brand-light flex items-center justify-center px-6">
      <div className="text-center">
        <h1 className="text-9xl font-heading font-extrabold text-brand-blue mb-4">404</h1>
        <h2 className="text-3xl font-bold text-brand-dark mb-4">Page Not Found</h2>
        <p className="text-brand-grey mb-8 max-w-md mx-auto">The page you are looking for doesn't exist or has been moved.</p>
        <Link to="/" className="inline-flex items-center gap-2 bg-brand-dark text-white px-8 py-3 rounded-xl font-medium hover:bg-brand-blue transition">
          <ArrowLeft size={20} /> Back to Home
        </Link>
      </div>
    </div>
  );
}